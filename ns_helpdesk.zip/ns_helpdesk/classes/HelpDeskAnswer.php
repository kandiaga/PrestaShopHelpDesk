<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class HelpDeskAnswer extends ObjectModel
{
    
    public $id_answer;  
    public $id_ticket;	
    public $message;
    public $date_add;
   

    public static $definition = [
        'table' => 'ns_helpdesk_answers',
        'primary' => 'id_answer',
        'fields' => [            
            'message' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml', 'required' => true],            
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            //'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
        ],
    ];

    public function __construct($id_answer = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_answer, $id_lang, $id_shop);
    }

    public static function getAll()
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'ns_helpdesk_answers ORDER BY date_add DESC';
        return Db::getInstance()->executeS($sql);
    }

    public static function getByIdTicket($id_ticket)
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'ns_helpdesk_answers WHERE id_ticket = ' . (int)$id_ticket;
        return Db::getInstance()->executeS($sql);
    }

    public static function createAnswer($id_ticket,$message)
    {
        $answer = new HelpDeskAnswer();
        $answer->id_ticket = (int)$id_ticket;       
        $answer->message = pSQL($message);        
        $answer->date_add = date('Y-m-d H:i:s');
		
        return $answer->add();
    }
	
	public static function addTicketAnswer($id_ticket, $message,$author)
    {
        $sql = 'INSERT INTO ' . _DB_PREFIX_ . 'ns_helpdesk_answers (id_ticket, message, author,date_add) VALUES (' . (int)$id_ticket . ', \'' . pSQL($message) . '\', \'' . pSQL($author) . '\',NOW())';
        return Db::getInstance()->execute($sql);
    }

    public static function updateAnswer($id_answer, $message)
    {
        $answer = new HelpDeskAnswer($id_answer);
        $answer->message = pSQL($message);
        $answer->date_upd = date('Y-m-d H:i:s');
		
        return $answer->update();
    }

    
}
