<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class HelpDeskTicket extends ObjectModel
{
    public $id_ticket;
    public $id_customer;
    public $subject;
    public $message;
    public $status;
    public $date_add;
    

    public static $definition = [
        'table' => 'ns_helpdesk_tickets',
        'primary' => 'id_ticket',
        'fields' => [
            'id_customer' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'subject' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'required' => true, 'size' => 255],
            'message' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml', 'required' => true],
            'status' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'required' => true, 'size' => 50],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            
        ],
    ];

    public function __construct($id_ticket = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_ticket, $id_lang, $id_shop);
    }

    public static function getTickets()
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'ns_helpdesk_tickets ORDER BY date_add DESC';
        return Db::getInstance()->executeS($sql);
    }

    public static function getTicketById($id_ticket)
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'ns_helpdesk_tickets WHERE id_ticket = ' . (int)$id_ticket;
        return Db::getInstance()->getRow($sql);
    }

    public static function createTicket($id_customer, $subject, $message, $status = 'open')
    {
        $ticket = new HelpDeskTicket();
        $ticket->id_customer = (int)$id_customer;
        $ticket->subject = pSQL($subject);
        $ticket->message = pSQL($message);
        $ticket->status = pSQL($status);
        $ticket->date_add = date('Y-m-d H:i:s');
        $ticket->date_upd = date('Y-m-d H:i:s');
        return $ticket->add();
    }

    public static function updateTicketStatus($id_ticket, $status)
    {
        $ticket = new HelpDeskTicket($id_ticket);
        $ticket->status = pSQL($status);
        $ticket->date_upd = date('Y-m-d H:i:s');
        return $ticket->update();
    }

    public static function closeTicket($id_ticket)
    {
        return self::updateTicketStatus($id_ticket, 'closed');
    }
	
	
	public static function getTicketByCustomer($id_customer)
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'ns_helpdesk_tickets WHERE id_customer = ' . (int)$id_customer;
        return Db::getInstance()->executeS($sql);
    }
}
