<?php

if (!defined('_PS_VERSION_')) {
    exit;
}


require_once(dirname(__FILE__) . '/classes/HelpDeskTicket.php'); 
require_once(dirname(__FILE__) . '/classes/HelpDeskAnswer.php'); 



class Ns_HelpDesk extends Module
{
    public function __construct()
    {
        $this->name = 'ns_helpdesk';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'NdiagaSoft';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Help Desk Support Ticket System');
        $this->description = $this->l('Module to handle support tickets from customers.');
    }

    public function install()
    {
        return parent::install() &&
               $this->installDb() &&
               $this->registerHook('displayCustomerAccount') &&
               $this->registerHook('displayAdminOrder') &&
			   $this->registerHook('displayNav1') &&
               $this->registerHook('displayBackOfficeHeader');
    }

    public function uninstall()
    {
      
	   $sql = array();
	  /*
		$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_helpdesk_tickets`';
		$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_helpdesk_answers`';
		*/
		
		if (!parent::uninstall() OR
            !$this->runSql($sql) 
        ) {
            return FALSE;
        }		
		
		return TRUE;		
		
    }

    protected function installDb()
    {
          $sql = array();
	   
	    $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_helpdesk_tickets` (
            `id_ticket` INT(11) NOT NULL AUTO_INCREMENT,
            `id_customer` INT(11) NOT NULL,
            `subject` VARCHAR(255) NOT NULL,
            `message` TEXT NOT NULL,
            `status` VARCHAR(50) NOT NULL DEFAULT "Open",
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_ticket`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=UTF8'; 
		
		$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_helpdesk_answers` (
            `id_answer` INT(11) NOT NULL AUTO_INCREMENT,
            `id_ticket` INT(11) NOT NULL,            
            `message` TEXT NOT NULL,
			`author` VARCHAR(50) NOT NULL DEFAULT "customer",
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_answer`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=UTF8';
		
		
		return $this->runSql($sql);

        
    }

    public function runSql($sql) {
        foreach ($sql as $s) {
			if (!Db::getInstance()->Execute($s)){
				return FALSE;
			}
        }
        return TRUE;
    }  
    

    public function getContent()
	{
		$output = null;

		if (Tools::isSubmit('submit' . $this->name)) {
			$adminEmail = Tools::getValue('NS_HELPDESK_ADMIN_EMAIL');

			if (!Validate::isEmail($adminEmail)) {
				$output .= $this->displayError($this->l('Invalid email address.'));
			} else {
				Configuration::updateValue('NS_HELPDESK_ADMIN_EMAIL', $adminEmail);
				$output .= $this->displayConfirmation($this->l('Settings updated.'));
			}
		}

		$adminLink = $this->context->link->getAdminLink('AdminHelpDesk');
		$output .= '<div class="panel">';
		$output .= '<h3>' . $this->l('Help Desk Settings') . '</h3>';
		$output .= '<p>' . $this->l('Manage your help desk tickets from the admin panel.') . '</p>';
		$output .= '<a href="' . $adminLink . '" class="btn btn-primary">' . $this->l('Go to Help Desk Admin') . '</a>';
		$output .= '</div>';

		return $output . $this->displayForm();
	}


    public function displayForm()
    {
        // Get default language
        $defaultLang = (int)Configuration::get('PS_LANG_DEFAULT');

        // Init Fields form array
        $fieldsForm[0]['form'] = [
            'legend' => [
                'title' => $this->l('Settings'),
            ],
            'input' => [
                [
                    'type' => 'text',
                    'label' => $this->l('Help Desk Admin Email'),
                    'name' => 'NS_HELPDESK_TITLE',
                    'size' => 20,
                    'required' => true,
                ],
            ],
            'submit' => [
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right',
            ],
        ];

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true; // false -> remove toolbar
        $helper->toolbar_scroll = true; // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = [
            'save' => [
                'desc' => $this->l('Save'),
                'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules'),
            ],
            'back' => [
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list'),
            ],
        ];

        // Load current value
        $helper->fields_value['NS_HELPDESK_TITLE'] = Configuration::get('NS_HELPDESK_TITLE');

        return $helper->generateForm($fieldsForm);
    }

    public function hookDisplayCustomerAccount($params)
    {
        $this->context->controller->addCSS($this->_path . 'views/css/ns_helpdesk.css', 'all');
        $this->context->controller->addJS($this->_path . 'views/js/ns_helpdesk.js');

        $link = $this->context->link->getModuleLink('ns_helpdesk', 'ticket');
        $this->context->smarty->assign('helpdesk_link', $link);

        return $this->display(__FILE__, 'views/templates/hook/customer_account.tpl');
    }

    public function hookDisplayAdminOrder($params)
    {
        // Code to display in admin order page
    }

    public function hookDisplayBackOfficeHeader($params)
    {
        $this->context->controller->addCSS($this->_path . 'views/css/ns_helpdesk.css', 'all');
        $this->context->controller->addJS($this->_path . 'views/js/ns_helpdesk.js');
    }
	
	public function hookDisplayNav1($params)
    {
        $this->context->controller->addCSS($this->_path . 'views/css/ns_helpdesk.css', 'all');
        $this->context->controller->addJS($this->_path . 'views/js/ns_helpdesk.js');

        $link = $this->context->link->getModuleLink('ns_helpdesk', 'ticket');
        $this->context->smarty->assign('helpdesk_link', $link);

        return $this->display(__FILE__, 'views/templates/hook/nav.tpl');
    }
	
	
	public function notifyAdminNewTicket($ticketId, $customerId, $subject, $message)
   {
    $context = Context::getContext();
    $shopName = Configuration::get('PS_SHOP_NAME');
    $adminEmail = Configuration::get('PS_SHOP_EMAIL');

    /* Retrieve customer information */
    $customer = new Customer($customerId);

    /* Prepare email template variables */
    $templateVars = [
        '{ticket_id}' => $ticketId,
        '{customer_id}' => $customerId,
        '{customer_name}' => $customer->firstname . ' ' . $customer->lastname,
        '{subject}' => $subject,
        '{message}' => $message,
        '{shop_name}' => $shopName,
    ];

    /* Send email */
    Mail::Send(
        (int)$context->language->id,
        'new_ticket_notification', /* Email template file name*/
        $this->l('New Help Desk Ticket Submitted'), /* Email subject*/
        $templateVars,
        $adminEmail, /* Recipient */
        null, /* Recipient name*/
        $customer->email, /* Sender email*/
        $customer->firstname . ' ' . $customer->lastname, /* Sender name*/
        null, /* File attachment*/
        null, /* Mode SMTP */
        dirname(__FILE__).'/mails/', /* Custom mail directory*/
        false, /* Die if error*/
        null, /* Reply to email*/
        null, /* Reply to name*/
        null /* From name */
    );
  }

	
	
}
