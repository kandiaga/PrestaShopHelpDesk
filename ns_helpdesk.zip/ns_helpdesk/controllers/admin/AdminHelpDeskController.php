<?php

class AdminHelpDeskController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'ns_helpdesk_tickets';
        $this->className = 'HelpDeskTicket';
		$this->identifier='id_ticket';
        $this->allow_export = true;

        parent::__construct();

        $this->fields_list = [
            'id_ticket' => ['title' => $this->l('ID'), 'align' => 'center', 'class' => 'fixed-width-xs'],
            'id_customer' => ['title' => $this->l('Customer ID')],
            'subject' => ['title' => $this->l('Subject')],
            'message' => ['title' => $this->l('Message')],
            'status' => [
                'title' => $this->l('Status'),
                'type' => 'text',
                'callback' => 'renderStatus',
                'orderby' => false,
                'search' => false,
            ],
            'date_add' => ['title' => $this->l('Date Added')],
        ];

        $this->actions = ['view', 'edit', 'delete','bulk_delete'];
		
		$this->bulk_actions = [
            'delete' => [
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
            ],
        ];
    }

    public function renderList()
    {
        return parent::renderList();
    }

    public function renderView()
    {
        $id_ticket = (int)Tools::getValue('id_ticket');
        $ticket = new HelpDeskTicket($id_ticket);
        $answers = $this->getTicketAnswers($id_ticket);

        $this->context->smarty->assign([
            'ticket' => $ticket,
            'answers' => $answers,
            'link' => $this->context->link,
        ]);

        return $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'ns_helpdesk/views/templates/admin/view_ticket.tpl');
    }

    public function renderForm()
    {
        if (Tools::isSubmit('updatens_helpdesk_tickets')) {
            return $this->renderUpdate();
        }

        return parent::renderForm();
    }

    public function renderUpdate()
    {
        $id_ticket = (int)Tools::getValue('id_ticket');
        $ticket = new HelpDeskTicket($id_ticket);

        $this->context->smarty->assign([
            'ticket' => $ticket,
            'link' => $this->context->link,
        ]);

        return $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'ns_helpdesk/views/templates/admin/update_ticket.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAnswer')) {
            $id_ticket = (int)Tools::getValue('id_ticket');
            $message = Tools::getValue('message');
			$author='admin';

            if ($this->addTicketAnswer($id_ticket, $message,$author)) {
                $this->confirmations[] = $this->l('Answer added successfully.');
            } else {
                $this->errors[] = $this->l('An error occurred while adding the answer.');
            }
        } elseif (Tools::isSubmit('submitUpdateTicket')) {
            $id_ticket = (int)Tools::getValue('id_ticket');
            $status = Tools::getValue('status');

            if ($this->updateTicketStatus($id_ticket, $status)) {
                $this->confirmations[] = $this->l('Ticket status updated successfully.');
            } else {
                $this->errors[] = $this->l('An error occurred while updating the ticket status.');
            }
        }
		
		elseif(Tools::isSubmit('submitBulkdelete' . $this->table)) {
        $ticketIds = Tools::getValue($this->table . 'Box');

        if (!empty($ticketIds) && is_array($ticketIds)) {
            foreach ($ticketIds as $id_ticket) {
                $this->deleteTicketAndAnswers($id_ticket);
            }
            $this->confirmations[] = $this->trans('Selected tickets and their related answers have been deleted successfully.', [], 'Admin.Notifications.Success');
        }
    }
		
		

        parent::postProcess();
    }

    public function renderStatus($status, $row)
    {
        $color = $status == 'open' ? 'red' : 'green';
        return '<span style="color:' . $color . ';">' . $status . '</span>';
    }

    private function getTicketAnswers($id_ticket)
    {
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'ns_helpdesk_answers WHERE id_ticket = ' . (int)$id_ticket . ' ORDER BY date_add ASC';
        return Db::getInstance()->executeS($sql);
    }

    private function addTicketAnswer($id_ticket, $message,$author)
    {
        $sql = 'INSERT INTO ' . _DB_PREFIX_ . 'ns_helpdesk_answers (id_ticket, message, author,date_add) VALUES (' . (int)$id_ticket . ', \'' . pSQL($message) . '\', \'' . pSQL($author) . '\',NOW())';
        return Db::getInstance()->execute($sql);
    }

    private function updateTicketStatus($id_ticket, $status)
    {
        $sql = 'UPDATE ' . _DB_PREFIX_ . 'ns_helpdesk_tickets SET status = \'' . pSQL($status) . '\' WHERE id_ticket = ' . (int)$id_ticket;
        return Db::getInstance()->execute($sql);
    }
	
	
	public function deleteTicketAndAnswers($id_ticket)
	{
		// Initialize database instance
		$db = Db::getInstance();

		// Delete related answers
		$deleteAnswersSql = 'DELETE FROM ' . _DB_PREFIX_ . 'ns_helpdesk_answers WHERE id_ticket = ' . (int)$id_ticket;
		$db->execute($deleteAnswersSql);

		// Delete the ticket itself
		$deleteTicketSql = 'DELETE FROM ' . _DB_PREFIX_ . 'ns_helpdesk_tickets WHERE id_ticket = ' . (int)$id_ticket;
		$db->execute($deleteTicketSql);
	}
	
	public function processDelete()
	{
		$id_ticket = (int)Tools::getValue('id_ticket');

		if ($id_ticket) {
			$this->deleteTicketAndAnswers($id_ticket);
			$this->confirmations[] = $this->trans('The ticket and its related answers have been deleted successfully.', [], 'Admin.Notifications.Success');
		}

		parent::processDelete();
	}


}
