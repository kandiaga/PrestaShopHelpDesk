<?php

class Ns_HelpDeskticketModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
		
		$id_customer = $this->context->customer->id;
		$all_tickets=HelpDeskTicket::getTicketByCustomer($id_customer);
		
		$this->context->smarty->assign('all_tickets', $all_tickets);
		$link_reply=$this->context->link->getModuleLink('ns_helpdesk', 'reply');
		
		$this->context->smarty->assign('link_reply', $link_reply);
		
		$this->context->smarty->assign([
        'logged' => $this->context->customer->isLogged(),
        'customer' => $this->context->customer,
        'link' => $this->context->link
    ]);
		

        $this->setTemplate('module:ns_helpdesk/views/templates/front/ticket.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitTicket')) {
            $customerId = $this->context->customer->id;
            $subject = Tools::getValue('subject');
            $message = Tools::getValue('message');
			
			$ticket = new HelpDeskTicket();
			$ticket->id_customer = $customerId;
			$ticket->subject = pSQL($subject);
			$ticket->message = pSQL($message);
			$ticket->status = 'Open';
			$ticket->date_add = date('Y-m-d H:i:s');
			
			/*

            Db::getInstance()->insert('ns_helpdesk_tickets', [
                'id_customer' => (int)$id_customer,
                'subject' => pSQL($subject),
                'message' => pSQL($message),
                'date_add' => date('Y-m-d H:i:s'),
            ]);
			*/
			
			if ($ticket->save()) {
        // Notify admin		
		     $module=Module::getInstanceByName('ns_helpdesk');
             $module->notifyAdminNewTicket($ticket->id, $customerId, $subject, $message);
			 
            $this->context->smarty->assign('confirmation', 'ok');
			
            }

			
        }
    }
}
