<?php

class Ns_HelpDeskreplyModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
		
		
		if(Tools::getValue('id_ticket')!=''){

        $id_ticket=(int)Tools::getValue('id_ticket');
		$ticket=new HelpDeskTicket($id_ticket);
		$answer_list=HelpDeskAnswer::getByIdTicket($id_ticket);
	   
	   $this->context->smarty->assign('ticket', $ticket);
	   $this->context->smarty->assign('answer_list', $answer_list);
	   
		}
		
	   else{
		   
		   $id_customer = $this->context->customer->id;
		$all_tickets=HelpDeskTicket::getTicketByCustomer($id_customer);
		
		$this->context->smarty->assign('all_tickets', $all_tickets);
		
		   
	   }
	   
	   $link_reply=$this->context->link->getModuleLink('ns_helpdesk', 'reply');	  
	   $this->context->smarty->assign('link_reply', $link_reply);

        $this->context->smarty->assign([
        'logged' => $this->context->customer->isLogged(),
        'customer' => $this->context->customer,
        'link' => $this->context->link
    ]);

        $this->setTemplate('module:ns_helpdesk/views/templates/front/answer.tpl');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitAnswer') && Tools::getValue('id_ticket')!='') {
            
            $id_ticket = Tools::getValue('id_ticket');
            $message = Tools::getValue('message');
			$author='customer';
            
			HelpDeskAnswer::addTicketAnswer($id_ticket, $message,$author);

            $this->context->smarty->assign('confirmation', 'ok');
        }
    }
}
